document.addEventListener('DOMContentLoaded', () => {
  const title = document.querySelector('.animated-title');
  const text = title.textContent;
  title.textContent = '';

  let index = 0;
  const type = () => {
    if (index < text.length) {
      title.textContent += text[index];
      index++;
      setTimeout(type, 80);
    }
  };
  type();
});
